#define nLAYERIB 3
#define nLAYER 7
#define nW 17
#define MONITOR_RANGE 5.0
#include "YDetectorGeometry.cxx"

YDetectorGeometry *yGEOM;
//gROOT->ProcessLine(".L YDetectorGeometry.cxx");

int* NTracks;
double *gradTrends;
double*** NetworkWeights;
double*** gradNetworkWeights;

static constexpr int NSubStave2[nLAYER] = { 1, 1, 1, 2, 2, 2, 2 };
const int NSubStave[nLAYER] = { 1, 1, 1, 2, 2, 2, 2 };
const int NStaves[nLAYER] = { 12, 16, 20, 24, 30, 42, 48 };
const int nHicPerStave[nLAYER] = { 1, 1, 1, 8, 8, 14, 14 };
const int nChipsPerHic[nLAYER] = { 9, 9, 9, 14, 14, 14, 14 };
const int ChipBoundary[nLAYER + 1] = { 0, 108, 252, 432, 3120, 6480, 14712, 24120 };
const int StaveBoundary[nLAYER + 1] = { 0, 12, 28, 48, 72, 102, 144, 192 };

int nSensorsbyLayer[nLAYER] 		= {	ChipBoundary[1] - ChipBoundary[0],
						ChipBoundary[2] - ChipBoundary[1],
						ChipBoundary[3] - ChipBoundary[2],
						ChipBoundary[4] - ChipBoundary[3],
						ChipBoundary[5] - ChipBoundary[4],
						ChipBoundary[6] - ChipBoundary[5],
						ChipBoundary[7] - ChipBoundary[6]	};

Bool_t LoadNTracks(Option_t * filename, int* NTrack)
{
   TString filen = filename;
   Int_t nc;
   Int_t nt;
   if (filen == "") {
      Error("LoadWeights()","Invalid file name");
      return kFALSE;
   }
   char *buff = new char[100];
   std::ifstream input(filen.Data());
   
   
   if (!input.is_open()) {
      delete[] buff;
      return kFALSE;
   }
   if (input.peek() == std::ifstream::traits_type::eof()) {
      return kFALSE; //empty
   }
   
   // neuron weights
   input.getline(buff, 200);
   input.getline(buff, 200);
   input.getline(buff, 200);      
   input.getline(buff, 200);         
   for(int ic = 0; ic < ChipBoundary[nLAYER]; ic++){
      input >> nc;
      input >> nt;
      NTrack[nc] = nt;            
   }    
   delete[] buff;
   return kTRUE;
}
Bool_t LoadWeights(Option_t * filename, double** NetworkWeight)
{
   TString filen = filename;
   Double_t w;
   if (filen == "") {
      Error("LoadWeights()","Invalid file name");
      return kFALSE;
   }
   char *buff = new char[100];
   std::ifstream input(filen.Data());
   
   
   if (!input.is_open()) {
      delete[] buff;
      return kFALSE;
   }
   if (input.peek() == std::ifstream::traits_type::eof()) {
      return kFALSE; //empty
   }
   
   // input normalzation
   input.getline(buff, 100);
   Float_t n1,n2;
   for(int lay=0; lay<nLAYER; lay++){
      input >> n1 >> n2;
      input >> n1 >> n2;         
   }
   input.getline(buff, 200);
   // output normalization
   input.getline(buff, 200);
   for(int lay=0; lay<nLAYER; lay++){
      input >> n1 >> n2;
      input >> n1 >> n2;         
      input >> n1 >> n2;               
   }
   input.getline(buff, 200);
   // neuron weights
   input.getline(buff, 200);

   int nentries = nW; 
   for(int ic = 0; ic < ChipBoundary[nLAYER]; ic++){
      input >> w;
      for (int iw=0; iw<nentries; iw++) { 
         input >> w;
         NetworkWeight[ic][iw] = w;
      }             
   }    
   delete[] buff;
   return kTRUE;
}

void getWeightGradients(double** preNW, double** postNW, double** gradNW){

   int nentries = nW; 
   for(int ic = 0; ic < ChipBoundary[nLAYER]; ic++){
      for (int iw=0; iw<nentries; iw++) { 
         gradNW[ic][iw] = postNW[ic][iw] - preNW[ic][iw];
      }             
   } 
}

void dumpWeightGradients(int nEpoch){

   TFile *file = new TFile(Form("WeightGradients.root"),"recreate");   

   for(int ic=0; ic<ChipBoundary[nLAYER]; ic++){
      if(NTracks[ic]<100) continue;
      double ep[nEpoch];
      double wg[nW][nEpoch];
      double sum_wg[nEpoch];      
      double sum =0;
      
      double monitor_range_np = 0;
      double monitor_range_ap = 0;      
      for(int ie=0; ie<nEpoch; ie++){
         ep[ie] = ie;
         sum_wg[ie] = 0;
         for(int ip=0; ip<nW; ip++){
            wg[ip][ie] = gradNetworkWeights[ie][ic][ip]*1e+4;
            sum += wg[ip][ie];
            sum_wg[ie] += TMath::Abs(wg[ip][ie]);
            if(ip>=2&&ip<11){
               if(TMath::Abs(wg[ip][ie])>monitor_range_np) monitor_range_np = TMath::Abs(wg[ip][ie]);
            } else if(ip>=11&&ip<17){
               if(TMath::Abs(wg[ip][ie])>monitor_range_ap) monitor_range_ap = TMath::Abs(wg[ip][ie]);
            }
         }
      }  
      
      TGraph* gr_sum_wg = new TGraph(nEpoch, ep, sum_wg);    
      gr_sum_wg->Fit("pol1");
      double slope = gr_sum_wg->GetFunction("pol1")->GetParameter(1);
      gradTrends[ic] = slope;
      TString gw_evolution = slope > 0 ? "+" : "-";
      
      int MonitorLEVEL = 0;
      if(monitor_range_ap<0.02) {
         MonitorLEVEL = 0;
         monitor_range_ap = 0.02;
      } else if (monitor_range_ap<0.2) {
         MonitorLEVEL = 1;
         monitor_range_ap = 0.2;         
      } else if (monitor_range_ap<2) {
         MonitorLEVEL = 2;
         monitor_range_ap = 2;                  
      } else {
         MonitorLEVEL = 3;
         monitor_range_ap = 20;                  
      }
      int layer       = yGEOM->GetLayer(ic);
      int halfbarrel  = yGEOM->GetHalfBarrel(ic);
      int staveID     = yGEOM->GetStave(ic);
      int halfstaveID = yGEOM->GetHalfStave(ic);
      int module      = yGEOM->GetModule(ic);  
      int chipIDmodule= yGEOM->GetChipIdInModule(ic);
 
      if(sum==0) continue;
      if(MonitorLEVEL<1) continue;
      

       
      //NP
      TGraph* gr_b1 = new TGraph(nEpoch, ep, wg[2]);    
      TGraph* gr_b2 = new TGraph(nEpoch, ep, wg[3]);    
      TGraph* gr_b3 = new TGraph(nEpoch, ep, wg[4]);    
      
      TGraph* gr_w11 = new TGraph(nEpoch, ep, wg[5]);    
      TGraph* gr_w21 = new TGraph(nEpoch, ep, wg[6]);    
      TGraph* gr_w12 = new TGraph(nEpoch, ep, wg[7]);    
      TGraph* gr_w22 = new TGraph(nEpoch, ep, wg[8]);    
      TGraph* gr_w13 = new TGraph(nEpoch, ep, wg[9]);    
      TGraph* gr_w23 = new TGraph(nEpoch, ep, wg[10]);   
      
      gr_b1->SetMarkerColor(2);
      gr_b2->SetMarkerColor(3);
      gr_b3->SetMarkerColor(4);    

      gr_w11->SetMarkerColor(2);
      gr_w21->SetMarkerColor(2);
      gr_w12->SetMarkerColor(3);    
      gr_w22->SetMarkerColor(3);
      gr_w13->SetMarkerColor(4);
      gr_w23->SetMarkerColor(4);          
                    
      gr_b1->SetMarkerStyle(20);
      gr_b2->SetMarkerStyle(20);
      gr_b3->SetMarkerStyle(20);    

      gr_w11->SetMarkerStyle(22);
      gr_w21->SetMarkerStyle(23);
      gr_w12->SetMarkerStyle(22);    
      gr_w22->SetMarkerStyle(23);
      gr_w13->SetMarkerStyle(22);
      gr_w23->SetMarkerStyle(23);   
        
      TMultiGraph *mg_NP = new TMultiGraph();
      mg_NP->Add(gr_b1,"p");
      mg_NP->Add(gr_b2,"p");    
      mg_NP->Add(gr_b3,"p");
      
      mg_NP->Add(gr_w11,"p");
      mg_NP->Add(gr_w21,"p");            
      mg_NP->Add(gr_w12,"p");            
      mg_NP->Add(gr_w22,"p");            
      mg_NP->Add(gr_w13,"p");            
      mg_NP->Add(gr_w23,"p");    
      
      mg_NP->SetTitle(Form("[Network Parameters] Chip %d, NTracks %d",ic,NTracks[ic]));
      mg_NP->GetXaxis()->SetTitle("Epoch");
      mg_NP->GetYaxis()->SetTitle("#Deltaw(#mum), #Deltab(#mum)");
      mg_NP->GetYaxis()->SetTitleOffset(1.2);
 
      // Change the axis limits
      mg_NP->GetXaxis()->SetLimits(-0.5, (nEpoch - 1) + 0.5);
      mg_NP->SetMinimum(-2.0*monitor_range_np);
      mg_NP->SetMaximum(+2.0*monitor_range_np);      
      
      file->cd();
   
      mg_NP->Draw("apl");
      auto legend = new TLegend(0.91,0.4,0.99,0.9);
      legend->AddEntry(gr_b1,"b1","p");
      legend->AddEntry(gr_b2,"b2","p");
      legend->AddEntry(gr_b3,"b3","p");
      
      legend->AddEntry(gr_w11,"w11","p");
      legend->AddEntry(gr_w21,"w21","p");
      legend->AddEntry(gr_w12,"w12","p");
      legend->AddEntry(gr_w22,"w22","p");
      legend->AddEntry(gr_w13,"w13","p");
      legend->AddEntry(gr_w23,"w23","p");                        
      legend->Draw("same");  
      mg_NP->Write(Form("[NP]_L%d_HB%d_S%d_HS%d_M%d_C%d_[%d%s]",layer,halfbarrel,staveID,halfstaveID,module,chipIDmodule,MonitorLEVEL,(const char*)gw_evolution));           

      //AP 
      TGraph* gr_R1 = new TGraph(nEpoch, ep, wg[11]);    
      TGraph* gr_R2 = new TGraph(nEpoch, ep, wg[12]);    
      TGraph* gr_R3 = new TGraph(nEpoch, ep, wg[13]);    
      TGraph* gr_T1 = new TGraph(nEpoch, ep, wg[14]);    
      TGraph* gr_T2 = new TGraph(nEpoch, ep, wg[15]);    
      TGraph* gr_T3 = new TGraph(nEpoch, ep, wg[16]);   
      
      gr_R1->SetMarkerColor(2);
      gr_R2->SetMarkerColor(3);
      gr_R3->SetMarkerColor(4);    
      gr_T1->SetMarkerColor(2);
      gr_T2->SetMarkerColor(3);
      gr_T3->SetMarkerColor(4);          
                   
      gr_R1->SetMarkerStyle(23);
      gr_R2->SetMarkerStyle(23);
      gr_R3->SetMarkerStyle(23);    
      gr_T1->SetMarkerStyle(20);
      gr_T2->SetMarkerStyle(20);
      gr_T3->SetMarkerStyle(20);   
        
      TMultiGraph *mg_AP = new TMultiGraph();      
      mg_AP->Add(gr_R1,"p");
      mg_AP->Add(gr_R2,"p");            
      mg_AP->Add(gr_R3,"p");            
      mg_AP->Add(gr_T1,"p");            
      mg_AP->Add(gr_T2,"p");            
      mg_AP->Add(gr_T3,"p");    
      
      mg_AP->SetTitle(Form("[Align Parameters] Chip %d, NTracks %d",ic,NTracks[ic]));
      mg_AP->GetXaxis()->SetTitle("Epoch");
      mg_AP->GetYaxis()->SetTitle("#Delta(#Theta)(#mum), #Delta(T)(#mum)");
      mg_AP->GetYaxis()->SetTitleOffset(1.2);
 
      // Change the axis limits
      mg_AP->GetXaxis()->SetLimits(-0.5, (nEpoch - 1) + 0.5);      
      mg_AP->SetMinimum(-1.0*monitor_range_ap);
      mg_AP->SetMaximum(+1.0*monitor_range_ap);      
      
      file->cd();
   
      mg_AP->Draw("apl");
      auto legend_AP = new TLegend(0.91,0.4,0.99,0.9);
      legend_AP->AddEntry(gr_R1,"R1","p");
      legend_AP->AddEntry(gr_R2,"R2","p");
      legend_AP->AddEntry(gr_R3,"R3","p");
      
      legend_AP->AddEntry(gr_T1,"T1","p");
      legend_AP->AddEntry(gr_T2,"T2","p");
      legend_AP->AddEntry(gr_T3,"T3","p");                       
      legend_AP->Draw("same");  
      mg_AP->Write(Form("[AP]_L%d_HB%d_S%d_HS%d_M%d_C%d_[%d%s]",layer,halfbarrel,staveID,halfstaveID,module,chipIDmodule,MonitorLEVEL,(const char*)gw_evolution));                           
   }   

   file->Write();
   delete file;
}

void dumpGradientTrends(){

   // x : chipID in stave n = nHicPerStave[l]*nChipsPerHic[l]
   // y : stave
   TVirtualPad *canvas = new TCanvas("dumpGradientTrends", "Alignment GradientTrends",1200,800);   

   gStyle->SetOptStat(0);
   TH2D*   hGradTrends[nLAYER];
   //gStyle->SetPaintTextFormat("1.0f");
   std::cout<<"YMultiLayerPerceptron::MonitorTracksBySensor Step 1"<<std::endl;   
   for(int l = 0; l < nLAYERIB; l++){
      int    nbinsX = nHicPerStave[l]*nChipsPerHic[l];
      int    nbinsY = NStaves[l];    

      TString hname  = "hL" + TString::Itoa(l,10) + "GradientTrend";
      TString htitle = "Gradient Trend Layer " + TString::Itoa(l,10);        
      hGradTrends[l] = new TH2D(hname,htitle,nbinsX,-0.5,nbinsX-0.5,nbinsY,-0.5,nbinsY-0.5);
      hGradTrends[l]->SetXTitle("ChipID in Stave");
      hGradTrends[l]->SetYTitle("StaveID");
      hGradTrends[l]->SetMaximum(+1);
      hGradTrends[l]->SetMinimum(-1);
      hGradTrends[l]->GetXaxis()->SetNdivisions(110);
      hGradTrends[l]->GetYaxis()->SetNdivisions(120);
      hGradTrends[l]->GetXaxis()->SetTickLength(0.01);
      hGradTrends[l]->GetYaxis()->SetTickLength(0.01);         
      hGradTrends[l]->GetZaxis()->SetLabelSize(0.02);
      
      for (int ypoint = 0; ypoint < (nbinsY/2); ypoint++) {
         hGradTrends[l]->GetYaxis()->SetBinLabel(ypoint+1+(nbinsY/2),Form("%d",ypoint));
      }         
      for (int ypoint = (nbinsY/2); ypoint < nbinsY; ypoint++) {
         hGradTrends[l]->GetYaxis()->SetBinLabel(ypoint+1-(nbinsY/2),Form("%d",ypoint));
      } 

   }
   for(int l = nLAYERIB; l < nLAYER; l++){
      int    nbinsX = (nHicPerStave[l]/2)*(nChipsPerHic[l]/2);
      int    nbinsY = NStaves[l]*NSubStave[l]*NSubStave2[l];    

      TString hname  = "hL" + TString::Itoa(l,10) + "GradientTrend";
      TString htitle = "Gradient Trend Layer " + TString::Itoa(l,10);        
      hGradTrends[l] = new TH2D(hname,htitle,nbinsX,-0.5,nbinsX-0.5,nbinsY,-0.5,nbinsY-0.5);
      hGradTrends[l]->SetXTitle("ModuleID in Half-Stave");
      hGradTrends[l]->SetYTitle("StaveID");
      hGradTrends[l]->GetYaxis()->SetTitleOffset(1.25);
      hGradTrends[l]->SetMaximum(+1);
      hGradTrends[l]->SetMinimum(-1);
      hGradTrends[l]->GetXaxis()->SetNdivisions(110);
      hGradTrends[l]->GetYaxis()->SetNdivisions(100);
      hGradTrends[l]->GetXaxis()->SetTickLength(0.01);
      hGradTrends[l]->GetYaxis()->SetTickLength(0.01);         
      hGradTrends[l]->GetZaxis()->SetLabelSize(0.02);

      for (int xpoint = 0; xpoint < (nHicPerStave[l]/2); xpoint++) {
         hGradTrends[l]->GetXaxis()->SetBinLabel((nChipsPerHic[l]/2)*xpoint+4,Form("M%d",xpoint));
         hGradTrends[l]->GetXaxis()->LabelsOption("h");
      }      
      for (int ypoint = 0; ypoint < (nbinsY/8); ypoint++) {
         hGradTrends[l]->GetYaxis()->SetBinLabel(NSubStave[l]*NSubStave2[l]*(ypoint+(nbinsY/8))+2,Form("%d",ypoint));
      }         
      for (int ypoint = (nbinsY/8); ypoint < (nbinsY/4); ypoint++) {
         hGradTrends[l]->GetYaxis()->SetBinLabel(NSubStave[l]*NSubStave2[l]*(ypoint-(nbinsY/8))+2,Form("%d",ypoint));
      }        
   }

   std::cout<<"YMultiLayerPerceptron::MonitorTracksBySensor Step 2"<<std::endl;      
   for(int ichipID = 0; ichipID < ChipBoundary[nLAYER]; ichipID++){
      double value = TMath::Abs(gradTrends[ichipID])< 1.0e-12 ? 0 : (gradTrends[ichipID] > 0 ? +1 : -1);
      
      int layer       = yGEOM->GetLayer(ichipID);
      int staveID     = yGEOM->GetStave(ichipID);
      int chipIDstave = yGEOM->GetChipIdInStave(ichipID);  
      if(layer<nLAYERIB){
         int xbin, ybin;
         int hb		  = yGEOM->GetHalfBarrel(ichipID);     
         ybin = staveID;
         if(hb==0) ybin = ybin + (NStaves[layer]/2);
         if(hb==1) ybin = ybin - (NStaves[layer]/2);
            
         xbin = chipIDstave;
         hGradTrends[layer]->SetBinContent(xbin+1, ybin+1, value);        
      } else {
         int xbin, ybin;
         int hb		  = yGEOM->GetHalfBarrel(ichipID); 
         int hs           = yGEOM->GetHalfStave(ichipID); 
         int ybinInStave  = chipIDstave%nChipsPerHic[layer] < nChipsPerHic[layer]/2 ? 2*hs+1 : 2*hs; 
         
         ybin = NSubStave[layer]*NSubStave2[layer]*staveID + ybinInStave;
         if(hb==0) ybin = ybin + NSubStave[layer]*NSubStave2[layer]*(NStaves[layer]/2);
         if(hb==1) ybin = ybin - NSubStave[layer]*NSubStave2[layer]*(NStaves[layer]/2);
         
         int md	= yGEOM->GetModule(ichipID);            
         int xbinInModule = chipIDstave%nChipsPerHic[layer] < nChipsPerHic[layer]/2 ? (chipIDstave%7) 
                                                                                    : std::abs((chipIDstave%7)-6); 
         xbin = 7*md + xbinInModule;     
         hGradTrends[layer]->SetBinContent(xbin+1, ybin+1, value);                        
      }
   }
   std::cout<<"YMultiLayerPerceptron::MonitorTracksBySensor Step 3"<<std::endl;      
   for(int l = 0; l < nLAYER; l++){
      canvas->Clear();          
      if(l<3) {
         canvas->cd(1);
         hGradTrends[l]->Draw("colz");  
      } else {
         hGradTrends[l]->Draw("colz");      
         int    nbinsX = (nHicPerStave[l]/2)*(nChipsPerHic[l]/2);
         int    nbinsY = NStaves[l]*NSubStave[l]*NSubStave2[l];         
         TLine* bdmodule[nHicPerStave[l]/2];
         for (int xpoint = 0; xpoint < (nHicPerStave[l]/2); xpoint++) {
            bdmodule[xpoint] = new TLine((nChipsPerHic[l]/2)*xpoint-0.5,-0.5,(nChipsPerHic[l]/2)*xpoint-0.5,nbinsY-0.5);
            bdmodule[xpoint]->Draw("same");
         }  
         TLine* bdstave[NStaves[l]];
         for (int ypoint = 0; ypoint < NStaves[l]; ypoint++) {
            bdstave[ypoint] = new TLine(-0.5,NSubStave[l]*NSubStave2[l]*ypoint-0.5,nbinsX-0.5,NSubStave[l]*NSubStave2[l]*ypoint-0.5);
            bdstave[ypoint]->Draw("same");            
         }                  
      }

      TString hGradTrendsname  = "GradientTrend_Layer" + TString::Itoa(l,10) + ".gif"; 
      canvas->SaveAs(hGradTrendsname,"gif");      
  
      //hGradTrends[l]->Reset();
      //delete hGradTrends[l];
   }
}


//Step 5 6 7 8 9 10
void checkWeightGradients_extended(int iepoch=-1, int fepoch=45){


   int nEpoch = fepoch - iepoch + 1;

   NTracks            = new int [ChipBoundary[nLAYER]];
   gradTrends         = new double [ChipBoundary[nLAYER]];
   for(int ic=0; ic<ChipBoundary[nLAYER]; ic++){
      NTracks[ic] = 0;
      gradTrends[ic] = 0;
   }

   NetworkWeights     = new double** [nEpoch];
   for(int ie=0; ie<nEpoch; ie++){
      NetworkWeights[ie]     = new double* [ChipBoundary[nLAYER]];
      for(int ic=0; ic<ChipBoundary[nLAYER]; ic++){
         NetworkWeights[ie][ic]     = new double [nW];
         for(int iw=0; iw<nW; iw++){
            NetworkWeights[ie][ic][iw]     = 0.0;
         } 
      }
   }       

   gradNetworkWeights = new double** [nEpoch-1];
   for(int ie=0; ie<nEpoch-1; ie++){
      gradNetworkWeights[ie] = new double* [ChipBoundary[nLAYER]];      
      for(int ic=0; ic<ChipBoundary[nLAYER]; ic++){
         gradNetworkWeights[ie][ic] = new double [nW];         
         for(int iw=0; iw<nW; iw++){
            gradNetworkWeights[ie][ic][iw] = 0.0;            
         } 
      }
   } 

   LoadNTracks("NTracks_Profile/NTracksBySensor_Epoch-1.txt", NTracks);  
   
   for(int epoch = iepoch; epoch <= fepoch; epoch++){
      TString wloc = Form("weights/weights_Epoch_At_%d.txt",epoch);
      LoadWeights(wloc,NetworkWeights[epoch-iepoch]);
   }

   for(int ie=0; ie<nEpoch; ie++){
      for(int ic=0; ic<5; ic++){
         std::cout<<"[Param NetworkWeights] Epoch "<<ie + iepoch<<" chipID "<<ic<<" ";  
         for(int iw=0; iw<nW; iw++){
            std::cout<<NetworkWeights[ie][ic][iw]<<" ";
         } 
         std::cout<<std::endl;
      }
   }   

   for(int ie=0; ie<nEpoch-1; ie++){
      getWeightGradients(NetworkWeights[ie], NetworkWeights[ie+1], gradNetworkWeights[ie]);
   }   
   
   for(int ie=0; ie<nEpoch-1; ie++){
      for(int ic=0; ic<5; ic++){
         std::cout<<"[Grad NetworkWeights]  Epoch "<<ie + iepoch<<" chipID "<<ic<<" ";  
         for(int iw=0; iw<nW; iw++){
            std::cout<<gradNetworkWeights[ie][ic][iw]<<" ";
         } 
         std::cout<<std::endl;
      }
   }      
   
   dumpWeightGradients(nEpoch-1);
   dumpGradientTrends();
}
